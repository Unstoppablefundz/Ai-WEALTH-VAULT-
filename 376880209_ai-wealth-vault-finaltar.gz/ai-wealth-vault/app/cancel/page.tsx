"use client";
import { motion } from "framer-motion";
import Link from "next/link";

export default function CancelPage() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center px-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-2xl p-10 max-w-md w-full text-center"
      >
        <div className="text-5xl mb-4">😔</div>
        <h1 className="font-heading font-bold text-2xl text-white mb-3">
          Payment Cancelled
        </h1>
        <p className="text-gray-400 font-body text-sm mb-6 leading-relaxed">
          No worries — your spot is still open. Whenever you're ready, the Vault is waiting.
        </p>

        <div className="glass rounded-xl p-5 mb-8 text-left">
          <p className="text-[#D4AF37] font-heading font-semibold text-sm mb-3">
            What you're missing:
          </p>
          <ul className="space-y-2 text-gray-400 font-body text-sm">
            <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✗</span> 500+ AI Prompt Packs</li>
            <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✗</span> Side Hustle Blueprints</li>
            <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✗</span> Automation Masterclass</li>
            <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✗</span> Private Community Access</li>
          </ul>
        </div>

        <a
          href="https://paylink.monnify.com/fGcbIC"
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold block w-full py-3 rounded-xl font-heading font-bold text-[#0A0A0A] mb-4"
        >
          Try Again — ₦2,000/mo
        </a>

        <Link href="/" className="text-gray-500 font-body text-sm hover:text-[#D4AF37] transition-colors">
          ← Back to home
        </Link>
      </motion.div>
    </div>
  );
}
