import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "The AI Wealth Vault — Build Wealth With Artificial Intelligence",
  description: "Join an elite community of AI-powered entrepreneurs. Access exclusive prompts, side hustle blueprints, automation tools, and more.",
  openGraph: {
    title: "The AI Wealth Vault",
    description: "The future belongs to those who build with AI.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-[#0A0A0A] text-white antialiased">{children}</body>
    </html>
  );
}
