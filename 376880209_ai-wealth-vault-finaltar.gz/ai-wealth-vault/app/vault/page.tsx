"use client";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const vaultContent = [
  {
    category: "AI Prompt Packs",
    icon: "🧠",
    items: [
      "500+ Business & Income Prompts",
      "ChatGPT Mastery Prompt Pack",
      "Content Creation Mega Pack",
      "Sales & Copywriting Prompts",
    ],
  },
  {
    category: "Side Hustle Blueprints",
    icon: "💼",
    items: [
      "AI Freelancing Blueprint (₦150k/mo)",
      "Digital Products Launchpad",
      "AI Consulting Playbook",
      "Faceless YouTube Automation",
    ],
  },
  {
    category: "Automation Tools",
    icon: "⚡",
    items: [
      "N8N Workflow Templates (30+)",
      "Make.com Automation Pack",
      "WhatsApp Bot Starter Kit",
      "AI Email Automation System",
    ],
  },
  {
    category: "Video Tutorials",
    icon: "🎥",
    items: [
      "AI Wealth Blueprint Masterclass",
      "ChatGPT for Business (6hrs)",
      "Automation Crash Course",
      "Digital Product Creation 101",
    ],
  },
  {
    category: "Community",
    icon: "🌐",
    items: [
      "Private Discord Server",
      "Telegram Inner Circle",
      "Weekly Live Q&A Calls",
      "Member Showcase Channel",
    ],
  },
];

export default function VaultPage() {
  const [verified, setVerified] = useState(false);
  const [checking, setChecking] = useState(true);
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    // Check if user has a verified session
    const session = localStorage.getItem("vault_access");
    if (session === "granted") {
      setVerified(true);
    }
    setChecking(false);
  }, []);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError("");

    // In production, this would call your API to verify Monnify payment
    // For now, we simulate a verification check
    await new Promise((r) => setTimeout(r, 1500));

    if (email.includes("@")) {
      localStorage.setItem("vault_access", "granted");
      localStorage.setItem("vault_email", email);
      setVerified(true);
    } else {
      setError("Please enter a valid email address.");
    }
    setSubmitting(false);
  };

  if (checking) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!verified) {
    return (
      <div className="min-h-screen bg-[#0A0A0A] flex items-center justify-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-10 max-w-md w-full text-center"
        >
          <div className="text-5xl mb-4">🔐</div>
          <h1 className="font-heading font-bold text-2xl text-white mb-2">
            Inner Vault Access
          </h1>
          <p className="text-gray-400 font-body text-sm mb-8">
            Enter the email you used to pay and we'll verify your membership.
          </p>

          <form onSubmit={handleVerify} className="space-y-4">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
              className="w-full bg-white/5 border border-[#D4AF37]/20 rounded-xl px-4 py-3 text-white font-body text-sm focus:outline-none focus:border-[#D4AF37]/60 placeholder-gray-600"
              required
            />
            {error && <p className="text-red-400 text-xs font-body">{error}</p>}
            <button
              type="submit"
              disabled={submitting}
              className="btn-gold w-full py-3 rounded-xl font-heading font-bold text-[#0A0A0A] disabled:opacity-50"
            >
              {submitting ? "Verifying..." : "Enter The Vault →"}
            </button>
          </form>

          <p className="text-gray-600 text-xs font-body mt-6">
            Haven't joined yet?{" "}
            <a href="https://paylink.monnify.com/fGcbIC" className="text-[#D4AF37] hover:underline">
              Get access for ₦2,000/mo
            </a>
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0A]">
      {/* Header */}
      <div className="border-b border-[#D4AF37]/10 bg-[#111111]">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <div className="font-heading font-bold text-lg">
              <span className="text-[#D4AF37]">AI</span>
              <span className="text-white"> WEALTH VAULT</span>
            </div>
            <p className="text-gray-500 font-body text-xs mt-0.5">Inner Vault — Members Only</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-green-400 font-body text-sm">Active Member</span>
          </div>
        </div>
      </div>

      {/* Welcome banner */}
      <div className="bg-gradient-to-r from-[#D4AF37]/10 via-[#D4AF37]/5 to-transparent border-b border-[#D4AF37]/10">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <h1 className="font-heading font-bold text-2xl text-white">
            Welcome to the Inner Vault 🏛️
          </h1>
          <p className="text-gray-400 font-body text-sm mt-1">
            You now have full access to all premium content. New drops every month.
          </p>
        </div>
      </div>

      {/* Content grid */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {vaultContent.map((section, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="glass rounded-2xl p-6 card-hover"
            >
              <div className="flex items-center gap-3 mb-5">
                <span className="text-2xl">{section.icon}</span>
                <h2 className="font-heading font-semibold text-white">{section.category}</h2>
              </div>
              <ul className="space-y-3">
                {section.items.map((item, j) => (
                  <li key={j} className="flex items-center gap-2 text-gray-300 font-body text-sm">
                    <span className="text-[#D4AF37] text-xs flex-shrink-0">◆</span>
                    <span className="hover:text-[#D4AF37] cursor-pointer transition-colors">
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
              <button className="mt-5 w-full btn-outline-gold py-2 rounded-lg font-body text-sm font-medium">
                Access All →
              </button>
            </motion.div>
          ))}
        </div>

        {/* Community links */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8 glass rounded-2xl p-8 text-center"
        >
          <h2 className="font-heading font-bold text-xl text-white mb-2">
            Join The Community 🔥
          </h2>
          <p className="text-gray-400 font-body text-sm mb-6">
            Connect with thousands of AI builders inside our private spaces.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#"
              className="btn-gold px-6 py-3 rounded-xl font-heading font-bold text-[#0A0A0A]"
            >
              💬 Join Discord
            </a>
            <a
              href="#"
              className="btn-outline-gold px-6 py-3 rounded-xl font-heading font-semibold"
            >
              📱 Join Telegram
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
