"use client";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#0A0A0A]/90 backdrop-blur-xl border-b border-[#D4AF37]/10"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="font-heading font-bold text-xl tracking-wide">
          <span className="text-[#D4AF37]">AI</span>
          <span className="text-white"> WEALTH VAULT</span>
        </div>

        <div className="hidden md:flex items-center gap-8 text-sm text-gray-400 font-body">
          <a href="#features" className="hover:text-[#D4AF37] transition-colors">Features</a>
          <a href="#packs" className="hover:text-[#D4AF37] transition-colors">Packs</a>
          <a href="#testimonials" className="hover:text-[#D4AF37] transition-colors">Community</a>
        </div>

        <a
          href="https://paylink.monnify.com/fGcbIC"
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold px-5 py-2.5 rounded-full text-sm font-heading font-bold tracking-wide"
        >
          Join The Vault
        </a>
      </div>
    </nav>
  );
}
