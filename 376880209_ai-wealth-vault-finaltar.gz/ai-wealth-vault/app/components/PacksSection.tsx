"use client";
import { motion } from "framer-motion";

const packs = [
  {
    icon: "🧠",
    title: "The Prompt Arsenal",
    tag: "Most Popular",
    description:
      "500+ battle-tested AI prompts for content creation, business automation, copywriting, and income generation. Updated monthly.",
    features: ["500+ Premium Prompts", "Monthly Updates", "Use-Case Library", "Prompt Chaining Guide"],
    color: "from-[#D4AF37]/20 to-transparent",
  },
  {
    icon: "💰",
    title: "Side Hustle Blueprints",
    tag: "Best Value",
    description:
      "Step-by-step AI-powered business blueprints — from freelancing to digital products to fully automated income streams.",
    features: ["12 Proven Blueprints", "AI Tool Stack", "Launch Checklist", "Revenue Projections"],
    color: "from-[#F5D77A]/15 to-transparent",
  },
  {
    icon: "⚡",
    title: "Automation Masterclass",
    tag: "Advanced",
    description:
      "Build AI automations that work while you sleep. N8N workflows, Zapier chains, and custom bots — all pre-built.",
    features: ["30+ Automation Flows", "N8N Templates", "Bot Builder Guide", "Passive Income Setup"],
    color: "from-[#D4AF37]/15 to-transparent",
  },
];

export default function PacksSection() {
  return (
    <section id="packs" className="relative py-28 bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] font-body text-sm tracking-[4px] uppercase mb-3">
            What's Inside
          </p>
          <h2 className="font-heading font-bold text-4xl md:text-5xl text-white mb-4">
            Featured <span className="text-[#D4AF37]">Vault Packs</span>
          </h2>
          <p className="text-gray-400 font-body max-w-xl mx-auto">
            Every pack is crafted to give you an unfair advantage in the AI economy.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {packs.map((pack, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="card-hover glass rounded-2xl p-8 relative overflow-hidden group cursor-pointer"
            >
              {/* Gradient bg */}
              <div className={`absolute inset-0 bg-gradient-to-br ${pack.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-6">
                  <span className="text-4xl">{pack.icon}</span>
                  <span className="text-xs font-body font-semibold text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 px-3 py-1 rounded-full">
                    {pack.tag}
                  </span>
                </div>

                <h3 className="font-heading font-bold text-xl text-white mb-3">{pack.title}</h3>
                <p className="text-gray-400 font-body text-sm leading-relaxed mb-6">
                  {pack.description}
                </p>

                <ul className="space-y-2">
                  {pack.features.map((f, j) => (
                    <li key={j} className="flex items-center gap-2 text-gray-300 font-body text-sm">
                      <span className="text-[#D4AF37] text-xs">◆</span>
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="text-center mt-10"
        >
          <p className="text-gray-500 font-body text-sm">
            All packs included with your{" "}
            <span className="text-[#D4AF37]">₦2,000/month</span> Vault Membership
          </p>
        </motion.div>
      </div>
    </section>
  );
}
