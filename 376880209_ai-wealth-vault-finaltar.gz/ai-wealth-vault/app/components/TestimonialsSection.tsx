"use client";
import { motion } from "framer-motion";

const testimonials = [
  {
    name: "Chidi O.",
    role: "Digital Entrepreneur, Lagos",
    avatar: "CO",
    quote:
      "The AI Wealth Vault changed everything. Within 60 days of joining, I launched two automated income streams using their blueprints. The ROI on ₦2,000/month is insane.",
  },
  {
    name: "Amara K.",
    role: "Freelancer & AI Consultant",
    avatar: "AK",
    quote:
      "I was skeptical at first. But the prompt packs alone are worth 100x the price. My clients pay me ₦150k+ per project now because I deliver results faster with these tools.",
  },
  {
    name: "Tunde B.",
    role: "Side Hustle Coach, Abuja",
    avatar: "TB",
    quote:
      "The community inside is fire. Everyone is actually building something real. The video tutorials are top-tier — better than most paid courses I've seen.",
  },
];

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="relative py-28 bg-[#0A0A0A] overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#D4AF37]/2 to-transparent" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] font-body text-sm tracking-[4px] uppercase mb-3">
            Vault Members Speak
          </p>
          <h2 className="font-heading font-bold text-4xl md:text-5xl text-white">
            Real People. <span className="text-[#D4AF37]">Real Wealth.</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="glass rounded-2xl p-8 relative card-hover"
            >
              {/* Quote mark */}
              <div className="text-[#D4AF37]/20 font-heading font-bold text-7xl absolute top-4 right-6 leading-none select-none">
                "
              </div>

              <div className="relative z-10">
                <p className="text-gray-300 font-body text-base leading-relaxed mb-8 italic">
                  "{t.quote}"
                </p>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#D4AF37] flex items-center justify-center">
                    <span className="text-[#0A0A0A] font-heading font-bold text-sm">
                      {t.avatar}
                    </span>
                  </div>
                  <div>
                    <p className="text-white font-heading font-semibold text-sm">{t.name}</p>
                    <p className="text-gray-500 font-body text-xs">{t.role}</p>
                  </div>
                  <div className="ml-auto text-[#D4AF37] text-sm">★★★★★</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
