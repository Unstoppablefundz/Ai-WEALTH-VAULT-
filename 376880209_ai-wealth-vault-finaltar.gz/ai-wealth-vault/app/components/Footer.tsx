"use client";

export default function Footer() {
  return (
    <footer className="bg-[#0A0A0A] py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
          <div>
            <div className="font-heading font-bold text-xl tracking-wide mb-2">
              <span className="text-[#D4AF37]">AI</span>
              <span className="text-white"> WEALTH VAULT</span>
            </div>
            <p className="text-gray-600 font-body text-sm">
              Building the AI-powered wealth community of the future.
            </p>
          </div>

          <div className="flex items-center gap-6 text-sm text-gray-500 font-body">
            <a href="#" className="hover:text-[#D4AF37] transition-colors">Privacy</a>
            <a href="#" className="hover:text-[#D4AF37] transition-colors">Terms</a>
            <a href="#" className="hover:text-[#D4AF37] transition-colors">Contact</a>
          </div>
        </div>

        <div className="section-divider mb-8" />

        <div className="text-center">
          <p className="text-[#D4AF37]/60 font-heading font-medium text-base md:text-lg italic tracking-wide">
            "The Future Belongs to Those Who Build With AI."
          </p>
          <p className="text-gray-700 font-body text-xs mt-4">
            © {new Date().getFullYear()} The AI Wealth Vault. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
