"use client";
import { motion } from "framer-motion";

export default function CTASection() {
  return (
    <section className="relative py-32 bg-[#111111] overflow-hidden">
      <div className="section-divider mb-0" />

      {/* Glowing background orb */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[600px] h-[600px] rounded-full bg-[#D4AF37]/5 blur-[100px]" />
      </div>

      <div className="max-w-4xl mx-auto px-6 text-center relative z-10 pt-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <p className="text-[#D4AF37] font-body text-sm tracking-[4px] uppercase mb-6">
            Limited Membership
          </p>

          <h2 className="font-heading font-bold text-5xl md:text-6xl lg:text-7xl text-white mb-6 leading-tight">
            Join The{" "}
            <span className="text-[#D4AF37] gold-glow">Inner Vault</span>
          </h2>

          <p className="text-gray-400 font-body text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
            Stop watching others build wealth with AI while you stand on the sidelines. 
            The door is open — but not forever.
          </p>

          <div className="glass rounded-2xl p-8 mb-10 max-w-lg mx-auto">
            <p className="text-gray-400 font-body text-sm mb-2">Full Vault Access</p>
            <div className="flex items-baseline justify-center gap-2 mb-4">
              <span className="text-[#D4AF37] font-heading font-bold text-5xl">₦2,000</span>
              <span className="text-gray-500 font-body">/month</span>
            </div>
            <ul className="text-gray-400 font-body text-sm space-y-2 mb-6 text-left">
              <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✓</span> All Vault Packs Included</li>
              <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✓</span> Monthly New Drops</li>
              <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✓</span> Private Community Access</li>
              <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✓</span> Video Tutorials & Masterclasses</li>
              <li className="flex items-center gap-2"><span className="text-[#D4AF37]">✓</span> Cancel Anytime</li>
            </ul>

            <a
              href="https://paylink.monnify.com/fGcbIC"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-gold block w-full py-4 rounded-xl font-heading font-bold text-lg text-[#0A0A0A] text-center animate-gold-pulse"
            >
              ⚡ Apply For Access Now
            </a>
          </div>

          <p className="text-gray-600 font-body text-sm">
            🔒 Secured by Monnify · Instant Access · Cancel Anytime
          </p>
        </motion.div>
      </div>

      <div className="section-divider mt-16" />
    </section>
  );
}
