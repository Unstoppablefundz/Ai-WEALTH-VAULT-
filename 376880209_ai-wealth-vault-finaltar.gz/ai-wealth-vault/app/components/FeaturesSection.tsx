"use client";
import { motion } from "framer-motion";

const features = [
  { icon: "🔐", title: "Exclusive Access", desc: "Content you won't find anywhere else. Curated for serious builders only." },
  { icon: "🤖", title: "AI-First Strategy", desc: "Every blueprint is engineered around cutting-edge AI tools and workflows." },
  { icon: "📈", title: "Proven Results", desc: "Members have generated millions using our systems. The data speaks." },
  { icon: "⚡", title: "Instant Delivery", desc: "Get access the moment your payment clears. No waiting, no friction." },
  { icon: "🌐", title: "Global Community", desc: "Join builders from 40+ countries inside our private Discord & Telegram." },
  { icon: "🔄", title: "Monthly Drops", desc: "Fresh content, new tools, and updated blueprints every single month." },
  { icon: "🎓", title: "Video Masterclasses", desc: "In-depth video tutorials from AI entrepreneurs who've done it." },
  { icon: "💎", title: "Premium Support", desc: "Direct access to our team. Your questions get real answers fast." },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="relative py-28 bg-[#111111]">
      <div className="section-divider mb-0" />
      <div className="max-w-7xl mx-auto px-6 pt-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="text-[#D4AF37] font-body text-sm tracking-[4px] uppercase mb-3">
            Why The Vault
          </p>
          <h2 className="font-heading font-bold text-4xl md:text-5xl text-white mb-4">
            Built for <span className="text-[#D4AF37]">Serious Players</span>
          </h2>
          <p className="text-gray-400 font-body max-w-xl mx-auto">
            Every feature is designed to give you maximum leverage in the new AI economy.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              className="glass rounded-xl p-6 card-hover group"
            >
              <span className="text-3xl mb-4 block group-hover:scale-110 transition-transform duration-300">
                {f.icon}
              </span>
              <h3 className="font-heading font-semibold text-white text-base mb-2">{f.title}</h3>
              <p className="text-gray-500 font-body text-sm leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <div className="section-divider mt-16" />
    </section>
  );
}
