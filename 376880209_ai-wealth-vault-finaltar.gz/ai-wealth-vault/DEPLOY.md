# 🚀 AI Wealth Vault — Deployment Guide

## Deploy to Vercel (5 minutes)

### Step 1: Push to GitHub
1. Create a new GitHub repo at github.com/new
2. In your project folder, run:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/ai-wealth-vault.git
   git push -u origin main
   ```

### Step 2: Deploy on Vercel
1. Go to vercel.com → "Add New Project"
2. Import your GitHub repo
3. Framework: Next.js (auto-detected)
4. Click Deploy — done!

### Step 3: Set Environment Variables in Vercel
In your Vercel project settings → Environment Variables, add:
- `MONNIFY_SECRET_KEY` = your Monnify secret key

### Step 4: Configure Monnify Webhook (optional)
In your Monnify dashboard, set webhook URL to:
`https://your-vercel-domain.vercel.app/api/webhook/monnify`

## Pages
- `/` — Landing page (public)
- `/vault` — Protected vault (members only)
- `/cancel` — Payment cancelled page

## Payment Flow
1. User clicks "Apply For Access" → redirected to Monnify paylink
2. After payment → user goes to /vault and enters their email
3. Email is verified against payment records

## Fonts
Using Google Fonts (Space Grotesk + Inter) — loaded via CSS import.
